pub type Addr = u64;
pub type Off = u64;
pub type Half = u16;
pub type Word = u32;
pub type SWord = i32;
pub type XWord = u64;
pub type SXWord = i64;
pub type UnsignedChar = u8;

use crate::types::header::elf::identifier::Data;

pub enum Type {
    Addr = 0,
    Off = 1,
    Half = 2,
    Word = 3,
    SWord = 4,
    XWord = 5,
    SXWord = 6,
    UnsignedChar = 7,
}

impl Type {
    pub fn size(&self) -> usize {
        match self {
            Self::Addr => 64,
            Self::Off => 64,
            Self::Half => 16,
            Self::Word => 32,
            Self::SWord => 32,
            Self::XWord => 64,
            Self::SXWord => 64,
            Self::UnsignedChar => 8,
        }
    }
}

pub fn read_addr(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> Addr {
    //
    let upper_bound = *offset + Type::Addr.size() / 8;
    let value = match endianess {
        Data::LSB => Addr::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => Addr::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_off(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> Off {
    let upper_bound = *offset + Type::Off.size() / 8;
    let value = match endianess {
        Data::LSB => Off::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => Off::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_half(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> Half {
    let upper_bound = *offset + Type::Half.size() / 8;
    let value = match endianess {
        Data::LSB => Half::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => Half::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_word(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> Word {
    let upper_bound = *offset + Type::Word.size() / 8;
    let value = match endianess {
        Data::LSB => Word::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => Word::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_sword(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> SWord {
    let upper_bound = *offset + Type::SWord.size() / 8;
    let value = match endianess {
        Data::LSB => SWord::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => SWord::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_xword(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> XWord {
    let upper_bound = *offset + Type::XWord.size() / 8;
    let value = match endianess {
        Data::LSB => XWord::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => XWord::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_sxword(filemap: &memmap2::Mmap, offset: &mut usize, endianess: &Data) -> SXWord {
    let upper_bound = *offset + Type::SXWord.size() / 8;
    let value = match endianess {
        Data::LSB => SXWord::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => SXWord::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}

pub fn read_unsigned_char(
    filemap: &memmap2::Mmap,
    offset: &mut usize,
    endianess: &Data,
) -> UnsignedChar {
    let upper_bound = *offset + Type::UnsignedChar.size() / 8;
    let value = match endianess {
        Data::LSB => UnsignedChar::from_le_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        Data::MSB => UnsignedChar::from_be_bytes(filemap[*offset..upper_bound].try_into().unwrap()),
        _ => panic!("Fail."),
    };
    *offset = upper_bound;
    value
}
