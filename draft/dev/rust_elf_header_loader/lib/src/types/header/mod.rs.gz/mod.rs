pub mod elf;

pub use elf::elf32::Header as Elf32;
pub use elf::elf64::Header as Elf64;
