use crate::types::data::arch32::Half;

type T = Half;

#[derive(Clone)]
pub enum ElfType {
    NONE = 0,        /* No file type */
    REL = 1,         /* Relocatable object file */
    EXEC = 2,        /* Executable file */
    DYN = 3,         /* Shared object file */
    CORE = 4,        /* Core file */
    NUM = 5,         /*Number of defined types */
    LOOS = 0xFE00,   /* Environment-specific use */
    HIOS = 0xFEFF,   /* Environment-specific use */
    LOPROC = 0xFF00, /* Processor-specific use */
    HIPROC = 0xFFFF, /* Processor-specific use */
    UNDEFINED = 6,   /* Undefined use */
}

type E = ElfType;

impl E {
    pub fn from(i: T) -> Self {
        match i {
            0 => Self::NONE,
            1 => Self::REL,
            2 => Self::EXEC,
            3 => Self::DYN,
            4 => Self::CORE,
            5 => Self::NUM,
            0xFE00 => Self::LOOS,
            0xFEFF => Self::HIOS,
            0xFF00 => Self::LOPROC,
            0xFFFF => Self::HIPROC,
            _ => Self::UNDEFINED,
        }
    }

    pub fn to(&self) -> T {
        match self {
            Self::NONE => 0,
            Self::REL => 1,
            Self::EXEC => 2,
            Self::DYN => 3,
            Self::CORE => 4,
            Self::NUM => 5,
            Self::LOOS => 0xFE00,
            Self::HIOS => 0xFEFF,
            Self::LOPROC => 0xFF00,
            Self::HIPROC => 0xFFFF,
            Self::UNDEFINED => 6,
        }
    }

    pub fn as_str(&self) -> &str {
        match self {
            Self::NONE => "NONE (No file type)",
            Self::REL => "REL (Relocatable object file type)",
            Self::EXEC => "EXEC (Executable file type)",
            Self::DYN => "DYN (Shared object file type)",
            Self::CORE => "CORE (Core file type)",
            Self::NUM => "NUM (Number of defined types)",
            Self::LOOS => "LOOS (Environment-specific type)",
            Self::HIOS => "HIOS (Environment-specific type)",
            Self::LOPROC => "LOPROC (Processor-specific type)",
            Self::HIPROC => "HIPROC (Processor-specific type)",
            Self::UNDEFINED => "UNDEFINED (Undefined type)",
        }
    }
}

use std::fmt::{Debug, Display, Formatter, Result};

impl Display for E {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        write!(f, "{}", self.as_str())
    }
}

impl Debug for E {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        write!(f, "{}", self.as_str())
    }
}
