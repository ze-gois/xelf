use crate::types::data::arch32::Word;

type T = Word;

/* Legal values for e_version (version).  */
pub enum Version {
    NONE = 0,    /* Invalid ELF version */
    CURRENT = 1, /* Current version */
    NUM = 2,
    UNDEFINED = 3,
}

type E = Version;

impl E {
    pub fn from(i: T) -> Self {
        match i {
            0 => Self::NONE,
            1 => Self::CURRENT,
            2 => Self::NUM,
            _ => Self::UNDEFINED,
        }
    }

    pub fn to(&self) -> T {
        match self {
            Self::NONE => 0,
            Self::CURRENT => 1,
            Self::NUM => 2,
            Self::UNDEFINED => 3,
        }
    }

    pub fn as_str(&self) -> &str {
        match self {
            Self::NONE => "Invalid ELF version",
            Self::CURRENT => "Current version",
            Self::NUM => "?  Number of version",
            Self::UNDEFINED => "Undefined version",
        }
    }
}

use std::fmt::{Debug, Display, Formatter, Result};

impl Display for E {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        write!(f, "{}", self.as_str())
    }
}

impl Debug for E {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        write!(f, "{}", self.as_str())
    }
}
