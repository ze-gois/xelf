pub mod etype;
pub mod machine;
pub mod version;

use super::identifier::Identifier;

pub use etype::ElfType;
pub use machine::Machine;
pub use version::Version;

pub use crate::types::data::arch64 as arch;

#[repr(C)]
pub struct Header {
    identifier: Identifier,
    etype: arch::Half,     /* Object file type */
    machine: arch::Half,   /* Machine type */
    version: arch::Word,   /* Object file version */
    entry: arch::Addr,     /* Entry point address */
    phoff: arch::Off,      /* Program header offset */
    shoff: arch::Off,      /* Section header offset */
    flags: arch::Word,     /* Processor-specific flags */
    ehsize: arch::Half,    /* ELF header size */
    phentsize: arch::Half, /* Size of program header entry */
    phnum: arch::Half,     /* Number of program header entries */
    shentsize: arch::Half, /* Size of section header entry */
    shnum: arch::Half,     /* Number of section header entries */
    shstrndx: arch::Half,  /* Section name string table index */
}

impl Header {
    pub fn load_from_filepath<P: AsRef<std::path::Path>>(fp: P) -> Self {
        let f = std::fs::File::open(fp).unwrap();
        let fm = unsafe { memmap2::Mmap::map(&f).unwrap() };
        Self::load_from_memmap(&fm).unwrap()
    }

    pub fn load_from_memmap(filemap: &memmap2::Mmap) -> Result<Self, &str> {
        let identifier = Identifier::load_from_memmap(&filemap);
        let endianess = identifier.get_data();

        let mut offset: usize = 16;

        Ok(Self {
            identifier,
            etype: arch::read_half(filemap, &mut offset, &endianess),
            machine: arch::read_half(filemap, &mut offset, &endianess),
            version: arch::read_word(filemap, &mut offset, &endianess),
            entry: arch::read_addr(filemap, &mut offset, &endianess),
            phoff: arch::read_off(filemap, &mut offset, &endianess),
            shoff: arch::read_off(filemap, &mut offset, &endianess),
            flags: arch::read_word(filemap, &mut offset, &endianess),
            ehsize: arch::read_half(filemap, &mut offset, &endianess),
            phentsize: arch::read_half(filemap, &mut offset, &endianess),
            phnum: arch::read_half(filemap, &mut offset, &endianess),
            shentsize: arch::read_half(filemap, &mut offset, &endianess),
            shnum: arch::read_half(filemap, &mut offset, &endianess),
            shstrndx: arch::read_half(filemap, &mut offset, &endianess),
        })
    }

    pub fn get_etype(&self) -> ElfType {
        ElfType::from(self.etype)
    }

    pub fn get_etype_string(&self) -> String {
        self.get_etype().as_str().to_string()
    }

    pub fn get_machine(&self) -> Machine {
        Machine::from(self.machine)
    }

    pub fn get_machine_string(&self) -> String {
        self.get_machine().as_str().to_string()
    }

    pub fn get_version(&self) -> Version {
        Version::from(self.version)
    }

    pub fn get_version_string(&self) -> String {
        self.get_version().as_str().to_string()
    }

    pub fn get_entry(&self) -> arch::Addr {
        self.entry.clone()
    }

    pub fn get_entry_str(&self) -> String {
        format!("{:#x}", self.get_entry())
    }

    pub fn get_phoff(&self) -> arch::Off {
        self.phoff.clone()
    }

    pub fn get_phoff_str(&self) -> String {
        format!("{}", self.get_phoff())
    }

    pub fn get_shoff(&self) -> arch::Off {
        self.shoff.clone()
    }

    pub fn get_shoff_str(&self) -> String {
        format!("{}", self.get_shoff())
    }

    pub fn get_flags(&self) -> arch::Word {
        self.flags.clone()
    }

    pub fn get_flags_str(&self) -> String {
        format!("0x{:x}", self.get_flags())
    }

    pub fn get_ehsize(&self) -> arch::Half {
        self.ehsize.clone()
    }

    pub fn get_ehsize_str(&self) -> String {
        format!("{} bytes", self.get_ehsize())
    }

    pub fn get_phentsize(&self) -> arch::Half {
        self.phentsize.clone()
    }

    pub fn get_phentsize_str(&self) -> String {
        format!("{} bytes", self.get_phentsize())
    }

    pub fn get_phnum(&self) -> arch::Half {
        self.phnum.clone()
    }

    pub fn get_phnum_str(&self) -> String {
        self.get_phnum().to_string()
    }

    pub fn get_shentsize(&self) -> arch::Half {
        self.shentsize.clone()
    }

    pub fn get_shentsize_str(&self) -> String {
        format!("{} bytes", self.get_shentsize())
    }

    pub fn get_shnum(&self) -> arch::Half {
        self.shnum.clone()
    }

    pub fn get_shnum_str(&self) -> String {
        self.get_shnum().to_string()
    }

    pub fn get_shstrndx(&self) -> arch::Half {
        self.shstrndx.clone()
    }

    pub fn get_shstrndx_str(&self) -> String {
        match self.get_shstrndx() {
            0 => String::from("No section name string table"),
            0xFFFF => String::from(
                "Section name string table index is greater than or equal to SHN_LORESERVE",
            ),
            _ => self.get_shstrndx().to_string(),
        }
    }

    pub fn get_identifier(&self) -> Identifier {
        self.identifier.clone()
    }
}

impl std::fmt::Display for Header {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Header64 {{
                \tIdentifier: {},
                Type: {},
                Machine: {},
                Version: {},
                Entry point address: {},
                Program header offset: {},
                Section header offset: {},
                Flags: {},
                ELF header size: {},
                Program header entry size: {},
                Number of program headers: {},
                Section header entry size: {},
                Number of section headers: {},
                Section name string table index: {}
            }}",
            self.get_identifier(),
            self.get_etype_string(),
            self.get_machine_string(),
            self.get_version_string(),
            self.get_entry_str(),
            self.get_phoff_str(),
            self.get_shoff_str(),
            self.get_flags_str(),
            self.get_ehsize_str(),
            self.get_phentsize_str(),
            self.get_phnum_str(),
            self.get_shentsize_str(),
            self.get_shnum_str(),
            self.get_shstrndx_str()
        )
    }
}
